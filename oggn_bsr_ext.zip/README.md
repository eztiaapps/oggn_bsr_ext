# oggn_bsr_ext
Stocks with good bsr score
